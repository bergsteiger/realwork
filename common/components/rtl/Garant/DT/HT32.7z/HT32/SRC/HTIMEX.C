/**********************************************************
     ����� ����権 ��७�� ������

     ���� - �.�.�����᪨�

     amArrToStr		static
     amTranslate	public
**********************************************************/
#include <htlocl.h>
#include <htglbx.h>
#include <htimex.h>
#define MEMOPT
#include <htmemo.h>
#include <htmixd.h>
#include <htrank.h>
#include <htstio.h>
#include <httime.h>

static void system amArrToStr( PCHR, word, PCHR, word );

/**********************************************************
     �८�ࠧ����� ���ᨢ ���⮢ � ���ᨢ ᨬ�����

     ������� ᨬ����, ���᪠� �� �� �ନ���஬ ��ப�
*/
static void system amArrToStr
(
PCHR	pDst,
word	wDstLen,
PCHR	pSrc,
word	wSrcLen)
{
PCHR	pEnd;
PCHR	pLast;

	pLast = pDst + wDstLen;
	pEnd = pDst + min( wSrcLen, wDstLen );
/* ���� ����뫪� ���⮢, �⫨��� �� 0 */
	for( ; pDst < pEnd; pDst++ ) {
		if( (*pDst = *pSrc++) == '\0' )
			break;
	}
/* ��������� ���⪨ ��ப� ᨬ����� �஡��� */
	for( ; pDst < pLast; pDst++ )
		*pDst = ' ';
}

/**********************************************************
     �८�ࠧ������ ⥫� ����� �� ������/��ᯮ��
*/
void system amTranslate
(
PCHR	pSrcRecord,	/* ��室��� ������ */
PCHR	pDstRecord,	/* ��஦������ ������ */
PIEVAR	pParm,		/* ��ࠬ���� �८�ࠧ������ ����� */
PIMPEX	pRules)		/* �ࠢ��� �८�ࠧ������ ����� */
{
char	 szBuff[260];
double	 eDouble;
float	 eFloat;
cint	 x;
cint	 y;
cint	 z;
union dword {
	byte  b[4];
	sword w[2];
	long  l;
} uDword;
word	wDLen;
word	wMin;
word	wSLen;
HDATE	sDate;
IEVAR	sParm;
PIMPEX	psEnd;
PCHR	pDst;
PCHR	pSrc;

/* �����쭠� ����� ��ࠬ��஢ */
	amMemMov( &sParm, pParm, sizeof(sParm) );
/* ��砫�� ��⠭���� */
	pSrcRecord += sParm.swSrcRecordOffset;
	wDLen = sParm.swDstRecordOffset;
	pDst = pDstRecord;
/* ���� �� �ᥬ ���� ��஦������ ����� */
	for( psEnd = pRules + sParm.nDstFieldCnt; pRules < psEnd; pRules++ ) {
		pDst += wDLen;
		pSrc = pSrcRecord + pRules->sofs;
		wDLen = pRules->dlen;
		wSLen = pRules->slen;
		wMin = min( wSLen, sizeof(szBuff) - 1 );
		switch( pRules->type ) {
	/* ���樠������ �ய�饭��� ����� */
		case FLD_CHAR:
			amSetMem( pDst, wDLen, ' ' );
			continue;
		case FLD_ARRA:
		case FLD_BYTE:
		case FLD_CURR:
		case FLD_DATE:
		case FLD_DFLT:
		case FLD_DWRD:
		case FLD_FLOA:
		case FLD_INTR:
		case FLD_LONG:
		case FLD_NMBR:
		case FLD_WORD:
			amZeroMem( pDst, wDLen );
			continue;
	/* �८�ࠧ������ �� ��ப���� ����� */
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_ARRA:
			if( wSLen < wDLen ) {
				amMemMov( pDst, pSrc, wSLen );
				amZeroMem( pDst + wSLen, wDLen - wSLen );
			}
			else	amMemMov( pDst, pSrc, wDLen );
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_CHAR:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_CHAR:
			amArrToStr( pDst, wDLen, pSrc, wSLen );
		/* ��४���஢�� ᨬ������ ������ */
			if( sParm.nAnsiType == AO_A2O )
				amAnsiToOem( pDst, wDLen );
			else if( sParm.nAnsiType == AO_O2A )
				amOemToAnsi( pDst, wDLen );
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_BYTE:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_BYTE:
			amMemMov( szBuff, pSrc, wMin );
			*(szBuff + wMin) = '\0';
			if( SSCANF( szBuff, cszInt, &x ) <= 0 )
				*pDst = '\0';
			else	*pDst = (byte)x;
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_DATE:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_DATE:
			amMemMov( szBuff, pSrc, wMin );
			*(szBuff + wMin) = '\0';
			x = y = z = 0;
			SSCANF( szBuff, sParm.szDateReadFmt, &x, &y, &z );
			if( sParm.nDateType == 4 ) {	/* mm-dd-yy */
				if( z < 1900 )
					sDate.year = (sint)(z + 1900);
				else	sDate.year = (sint)z;
				sDate.month = (char)x;
				sDate.day = (char)y;
			}
			else if( sParm.nDateType >= 5 ) {/* yy-mm-dd */
				if( x < 1900 )
					sDate.year = (sint)(x + 1900);
				else	sDate.year = (sint)x;
				sDate.month = (char)y;
				sDate.day = (char)z;
			}
			else {				/* dd-mm-yy */
				if( z < 1900 )
					sDate.year = (sint)(z + 1900);
				else	sDate.year = (sint)z;
				sDate.month = (char)y;
				sDate.day = (char)x;
			}
		/* ������� ����७��� �ଠ� */
			*(PSWRD)pDst = amDateToNum( &sDate );
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_DFLT:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_DFLT:
			amMemMov( szBuff, pSrc, wMin );
			*(szBuff + wMin) = '\0';
			amCaseLow( szBuff, wMin );
			if( SSCANF( szBuff, cszDub, &eDouble ) <= 0 )
				*(double *)pDst = 0;
			else	*(double *)pDst = eDouble;
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_DWRD:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_DWRD:
			amMemMov( szBuff, pSrc, wMin );
			*(szBuff + wMin) = '\0';
			if( SSCANF( szBuff, cszDwd, (PDWRD)pDst ) <= 0 )
				*(PDWRD)pDst = 0L;
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_FLOA:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_FLOA:
			amMemMov( szBuff, pSrc, wMin );
			*(szBuff + wMin) = '\0';
			amCaseLow( szBuff, wMin );
			if( SSCANF( szBuff, cszFlt, &eFloat ) <= 0 )
				*(PLINT)pDst = 0L;
			else	*(float *)pDst = eFloat;
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_INTR:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_INTR:
			amMemMov( szBuff, pSrc, wMin );
			*(szBuff + wMin) = '\0';
			if( SSCANF( szBuff, cszInt, (PSINT)pDst ) <= 0 )
				*(PSINT)pDst = 0;
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_LONG:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_LONG:
			amMemMov( szBuff, pSrc, wMin );
			*(szBuff + wMin) = '\0';
			if( SSCANF( szBuff, cszLng, (PLINT)pDst ) <= 0 )
				*(PLINT)pDst = 0L;
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_NMBR:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_NMBR:
			amMemMov( szBuff, pSrc, wMin );
			*(szBuff + wMin) = '\0';
			if( SSCANF( szBuff, cszLng, &uDword.l ) <= 0 )
				uDword.l = 0L;
			*(PSWRD)pDst = uDword.w[0];
			*(PUCHR)(pDst+sizeof(sint)) = uDword.b[2];
			break;
		case (FLD_ARRA + 1) * FLD_TYPE + FLD_WORD:
		case (FLD_CHAR + 1) * FLD_TYPE + FLD_WORD:
			amMemMov( szBuff, pSrc, wMin );
			*(szBuff + wMin) = '\0';
			if( SSCANF( szBuff, cszWrd, (PSINT)pDst ) <= 0 )
				*(PSINT)pDst = 0;
			break;
	/* �८�ࠧ������ �� ���� */
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_CHAR:
			SPRINTF( szBuff, cszAint, wDLen, *pSrc & 0xff );
			amMemMov( pDst, szBuff, wDLen );
			break;
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_BYTE:
			*(PUCHR)pDst = *(PUCHR)pSrc;
			break;
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_DATE:
			*(PSWRD)pDst = (sword)*(PUCHR)pSrc;
			break;
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_DFLT:
			*(double *)pDst = (double)*(PUCHR)pSrc;
			break;
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_DWRD:
			*(PDWRD)pDst = (dword)*(PUCHR)pSrc;
			break;
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_FLOA:
			*(float *)pDst = (float)*(PUCHR)pSrc;
			break;
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_INTR:
			*(PSINT)pDst = (sint)*(PUCHR)pSrc;
			break;
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_LONG:
			*(PLINT)pDst = (long)*(PUCHR)pSrc;
			break;
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_NMBR:
			*(PSWRD)pDst = (sword)*(PUCHR)pSrc;
			*(PUCHR)(pDst+sizeof(sword)) = '\0';
			break;
		case (FLD_BYTE + 1) * FLD_TYPE + FLD_WORD:
			*(PSWRD)pDst = (sword)*(PUCHR)pSrc;
			break;
	/* �८�ࠧ������ �� ���� */
		case (FLD_DATE + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_DATE + 1) * FLD_TYPE + FLD_CHAR:
			amNumToDate( *(PSWRD)pSrc, &sDate );
			if( sParm.nDateType == 4 ) {	/* mm-dd-yy */
				z = sDate.year;
				if( !sParm.bFullCentury && z >= 1900 ) {
					z -= 1900;
					if( z >= 100 )
						z -= 100;
				}					
				x = sDate.month;
				y = sDate.day;
			}
			else if( sParm.nDateType >= 5 ) {/* yy-mm-dd */
				x = sDate.year;
				if( !sParm.bFullCentury && x >= 1900 ) {
					x -= 1900;
					if( x >= 100 )
						x -= 100;
				}
				y = sDate.month;
				z = sDate.day;
			}
			else {				/* dd-mm-yy */
				z = sDate.year;
				if( !sParm.bFullCentury && z >= 1900 ) {
					z -= 1900;
					if( z >= 100 )
						z -= 100;
				}
				y = sDate.month;
				x = sDate.day;
			}
			SPRINTF( szBuff, sParm.szDateWriteFmt, x, y, z );
			amMemMov( pDst, szBuff, wDLen );
			break;
		case (FLD_DATE + 1) * FLD_TYPE + FLD_BYTE:
			*(PUCHR)pDst = (byte)*(PSWRD)pSrc;
			break;
		case (FLD_DATE + 1) * FLD_TYPE + FLD_DATE:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			break;
		case (FLD_DATE + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_DATE + 1) * FLD_TYPE + FLD_DFLT:
			*(double *)pDst = (double)*(PSWRD)pSrc;
			break;
		case (FLD_DATE + 1) * FLD_TYPE + FLD_DWRD:
			*(PDWRD)pDst = (dword)*(PSWRD)pSrc;
			break;
		case (FLD_DATE + 1) * FLD_TYPE + FLD_FLOA:
			*(float *)pDst = (float)*(PSWRD)pSrc;
			break;
		case (FLD_DATE + 1) * FLD_TYPE + FLD_INTR:
			*(PSINT)pDst = *(PSINT)pSrc;
			break;
		case (FLD_DATE + 1) * FLD_TYPE + FLD_LONG:
			*(PLINT)pDst = (long)*(PSWRD)pSrc;
			break;
		case (FLD_DATE + 1) * FLD_TYPE + FLD_NMBR:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			*(PUCHR)(pDst+sizeof(sint)) = '\0';
			break;
		case (FLD_DATE + 1) * FLD_TYPE + FLD_WORD:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			break;
	/* �८�ࠧ������ �� �������� ����⢨⥫쭮�� (�����) */
		case (FLD_CURR + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_CURR + 1) * FLD_TYPE + FLD_CHAR:
			SPRINTF( szBuff, sParm.szCurrencyFmt, *(double *)pSrc );
		/* �ਦ��� �᫮ ��ࠢ�, �᫨ ���� ���� */
			if( (wSLen = amStrLen( szBuff )) < wDLen ) {
				amSetMem( pDst, wDLen, ' ' );
				amMemMov( pDst + wDLen - wSLen, szBuff, wSLen );
			}
			else	amMemMov( pDst, szBuff, wDLen );
			break;
	/* �८�ࠧ������ �� �������� ����⢨⥫쭮�� */
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_CHAR:
			SPRINTF( szBuff, sParm.szDoubleFmt, *(double *)pSrc );
		/* �ਦ��� �᫮ ��ࠢ�, �᫨ ���� ���� */
			if( (wSLen = amStrLen( szBuff )) < wDLen ) {
				amSetMem( pDst, wDLen, ' ' );
				amMemMov( pDst + wDLen - wSLen, szBuff, wSLen );
			}
			else	amMemMov( pDst, szBuff, wDLen );
			break;
		case (FLD_CURR + 1) * FLD_TYPE + FLD_BYTE:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_BYTE:
			*(PUCHR)pDst = (byte)*(double *)pSrc;
			break;
		case (FLD_CURR + 1) * FLD_TYPE + FLD_DATE:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_DATE:
			*(PSWRD)pDst = (sword)*(double *)pSrc;
			break;
		case (FLD_CURR + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_CURR + 1) * FLD_TYPE + FLD_DFLT:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_DFLT:
			*(double *)pDst = *(double *)pSrc;
			break;
		case (FLD_CURR + 1) * FLD_TYPE + FLD_DWRD:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_DWRD:
			*(PDWRD)pDst = (dword)*(double *)pSrc;
			break;
		case (FLD_CURR + 1) * FLD_TYPE + FLD_FLOA:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_FLOA:
			*(float *)pDst = (float)*(double *)pSrc;
			break;
		case (FLD_CURR + 1) * FLD_TYPE + FLD_INTR:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_INTR:
			*(PSINT)pDst = (sint)*(double *)pSrc;
			break;
		case (FLD_CURR + 1) * FLD_TYPE + FLD_LONG:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_LONG:
			*(PLINT)pDst = (long)*(double *)pSrc;
			break;
		case (FLD_CURR + 1) * FLD_TYPE + FLD_NMBR:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_NMBR:
			uDword.l = (long)*(double *)pSrc;
			*(PSWRD)pDst = uDword.w[0];
			*(PUCHR)(pDst+sizeof(sint)) = uDword.b[2];
			break;
		case (FLD_CURR + 1) * FLD_TYPE + FLD_WORD:
		case (FLD_DFLT + 1) * FLD_TYPE + FLD_WORD:
			*(PSWRD)pDst = (sword)*(double *)pSrc;
			break;
	/* �८�ࠧ������ �� �������� 楫��� ��� ����� */
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_CHAR:
			SPRINTF( szBuff, cszAdwd, wDLen, *(PDWRD)pSrc );
			amMemMov( pDst, szBuff, wDLen );
			break;
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_BYTE:
			*(PUCHR)pDst = (byte)*(PDWRD)pSrc;
			break;
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_DATE:
			*(PSWRD)pDst = (sword)*(PDWRD)pSrc;
			break;
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_DWRD:
			*(PDWRD)pDst = *(PDWRD)pSrc;
			break;
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_FLOA:
			*(float *)pDst = (float)*(PDWRD)pSrc;
			break;
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_DFLT:
			*(double *)pDst = (double)*(PDWRD)pSrc;
			break;
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_INTR:
			*(PSINT)pDst = (sint)*(PDWRD)pSrc;
			break;
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_LONG:
			*(PLINT)pDst = (long)*(PDWRD)pSrc;
			break;
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_NMBR:
			uDword.l = *(PLINT)pSrc;
			*(PSWRD)pDst = uDword.w[0];
			*(PUCHR)(pDst+sizeof(sint)) = uDword.b[2];
			break;
		case (FLD_DWRD + 1) * FLD_TYPE + FLD_WORD:
			*(PSWRD)pDst = (sword)*(PDWRD)pSrc;
			break;
	/* �८�ࠧ������ �� ����⢨⥫쭮�� */
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_CHAR:
			SPRINTF( szBuff, sParm.szFloatFmt, *(float *)pSrc );
		/* �ਦ��� �᫮ ��ࠢ�, �᫨ ���� ���� */
			if( (wSLen = amStrLen( szBuff )) < wDLen ) {
				amSetMem( pDst, wDLen, ' ' );
				amMemMov( pDst + wDLen - wSLen, szBuff, wSLen );
			}
			else	amMemMov( pDst, szBuff, wDLen );
			break;
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_BYTE:
			*(PUCHR)pDst = (byte)*(float *)pSrc;
			break;
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_DATE:
			*(PSWRD)pDst = (sword)*(float *)pSrc;
			break;
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_DFLT:
			*(double *)pDst = (double)*(float *)pSrc;
			break;
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_DWRD:
			*(PDWRD)pDst = (dword)*(float *)pSrc;
			break;
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_FLOA:
			*(float *)pDst = (float)*(float *)pSrc;
			break;
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_INTR:
			*(PSINT)pDst = (sint)*(float *)pSrc;
			break;
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_LONG:
			*(PLINT)pDst = (long)*(float *)pSrc;
			break;
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_NMBR:
			uDword.l = (long)*(float *)pSrc;
			*(PSWRD)pDst = uDword.w[0];
			*(PUCHR)(pDst+sizeof(sint)) = uDword.b[2];
			break;
		case (FLD_FLOA + 1) * FLD_TYPE + FLD_WORD:
			*(PSWRD)pDst = (sword)*(float *)pSrc;
			break;
	/* �८�ࠧ������ �� 楫��� */
		case (FLD_INTR + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_INTR + 1) * FLD_TYPE + FLD_CHAR:
			SPRINTF( szBuff, cszAint, wDLen, *(PSINT)pSrc );
			amMemMov( pDst, szBuff, wDLen );
			break;
		case (FLD_INTR + 1) * FLD_TYPE + FLD_BYTE:
			*(PUCHR)pDst = (byte)*(PSINT)pSrc;
			break;
		case (FLD_INTR + 1) * FLD_TYPE + FLD_DATE:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			break;
		case (FLD_INTR + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_INTR + 1) * FLD_TYPE + FLD_DFLT:
			*(double *)pDst = (double)*(PSINT)pSrc;
			break;
		case (FLD_INTR + 1) * FLD_TYPE + FLD_DWRD:
			*(PDWRD)pDst = (dword)*(PSINT)pSrc;
			break;
		case (FLD_INTR + 1) * FLD_TYPE + FLD_FLOA:
			*(float *)pDst = (float)*(PSINT)pSrc;
			break;
		case (FLD_INTR + 1) * FLD_TYPE + FLD_INTR:
			*(PSINT)pDst = *(PSINT)pSrc;
			break;
		case (FLD_INTR + 1) * FLD_TYPE + FLD_LONG:
			*(PLINT)pDst = (long)*(PSINT)pSrc;
			break;
		case (FLD_INTR + 1) * FLD_TYPE + FLD_NMBR:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			*(PUCHR)(pDst+sizeof(sint)) = '\0';
			break;
		case (FLD_INTR + 1) * FLD_TYPE + FLD_WORD:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			break;
	/* �८�ࠧ������ �� �������� 楫��� */
		case (FLD_LONG + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_LONG + 1) * FLD_TYPE + FLD_CHAR:
			SPRINTF( szBuff, cszAlng, wDLen, *(PLINT)pSrc );
			amMemMov( pDst, szBuff, wDLen );
			break;
		case (FLD_LONG + 1) * FLD_TYPE + FLD_BYTE:
			*(PUCHR)pDst = (byte)*(PLINT)pSrc;
			break;
		case (FLD_LONG + 1) * FLD_TYPE + FLD_DATE:
			*(PSWRD)pDst = (sword)*(PLINT)pSrc;
			break;
		case (FLD_LONG + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_LONG + 1) * FLD_TYPE + FLD_DFLT:
			*(double *)pDst = (double)*(PLINT)pSrc;
			break;
		case (FLD_LONG + 1) * FLD_TYPE + FLD_DWRD:
			*(PDWRD)pDst = (dword)*(PLINT)pSrc;
			break;
		case (FLD_LONG + 1) * FLD_TYPE + FLD_FLOA:
			*(float *)pDst = (float)*(PLINT)pSrc;
			break;
		case (FLD_LONG + 1) * FLD_TYPE + FLD_INTR:
			*(PSINT)pDst = (sint)*(PLINT)pSrc;
			break;
		case (FLD_LONG + 1) * FLD_TYPE + FLD_LONG:
			*(PLINT)pDst = *(PLINT)pSrc;
			break;
		case (FLD_LONG + 1) * FLD_TYPE + FLD_NMBR:
			uDword.l = *(PLINT)pSrc;
			*(PSWRD)pDst = uDword.w[0];
			*(PUCHR)(pDst+sizeof(sint)) = uDword.b[2];
			break;
		case (FLD_LONG + 1) * FLD_TYPE + FLD_WORD:
			*(PSWRD)pDst = (sword)*(PLINT)pSrc;
			break;
	/* �८�ࠧ������ �� ����� */
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_CHAR:
			uDword.l = *(PLINT)pSrc;
			uDword.b[3] = '\0';
			SPRINTF( szBuff, cszAlng, wDLen, uDword.l );
			amMemMov( pDst, szBuff, wDLen );
			break;
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_BYTE:
			uDword.l = *(PLINT)pSrc;
			uDword.b[3] = '\0';
			*(PUCHR)pDst = (byte)uDword.l;
			break;
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_DATE:
			uDword.l = *(PLINT)pSrc;
			uDword.b[3] = '\0';
			*(PSWRD)pDst = (sword)uDword.l;
			break;
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_DFLT:
			uDword.l = *(PLINT)pSrc;
			uDword.b[3] = '\0';
			*(double *)pDst = (double)uDword.l;
			break;
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_FLOA:
			uDword.l = *(PLINT)pSrc;
			uDword.b[3] = '\0';
			*(float *)pDst = (float)uDword.l;
			break;
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_INTR:
			uDword.l = *(PLINT)pSrc;
			uDword.b[3] = '\0';
			*(PSINT)pDst = (sint)uDword.l;
			break;
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_DWRD:
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_LONG:
			uDword.l = *(PLINT)pSrc;
			uDword.b[3] = '\0';
			*(PLINT)pDst = uDword.l;
			break;
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_NMBR:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			*(PUCHR)(pDst+sizeof(sint)) = *(PUCHR)(pSrc+2);
			break;
		case (FLD_NMBR + 1) * FLD_TYPE + FLD_WORD:
			uDword.l = *(PLINT)pSrc;
			uDword.b[3] = '\0';
			*(PSWRD)pDst = (sword)uDword.l;
			break;
	/* �८�ࠧ������ �� ������������ 楫��� */
		case (FLD_WORD + 1) * FLD_TYPE + FLD_ARRA:
		case (FLD_WORD + 1) * FLD_TYPE + FLD_CHAR:
			SPRINTF( szBuff, cszAwrd, wDLen, *(PSWRD)pSrc );
			amMemMov( pDst, szBuff, wDLen );
			break;
		case (FLD_WORD + 1) * FLD_TYPE + FLD_BYTE:
			*(PUCHR)pDst = (byte)*(PSWRD)pSrc;
			break;
		case (FLD_WORD + 1) * FLD_TYPE + FLD_DATE:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			break;
		case (FLD_WORD + 1) * FLD_TYPE + FLD_CURR:
		case (FLD_WORD + 1) * FLD_TYPE + FLD_DFLT:
			*(double *)pDst = (double)*(PSWRD)pSrc;
			break;
		case (FLD_WORD + 1) * FLD_TYPE + FLD_DWRD:
			*(PDWRD)pDst = (dword)*(PSWRD)pSrc;
			break;
		case (FLD_WORD + 1) * FLD_TYPE + FLD_FLOA:
			*(float *)pDst = (float)*(PSWRD)pSrc;
			break;
		case (FLD_WORD + 1) * FLD_TYPE + FLD_INTR:
			*(PSINT)pDst = *(PSINT)pSrc;
			break;
		case (FLD_WORD + 1) * FLD_TYPE + FLD_LONG:
			*(PLINT)pDst = (long)*(PSWRD)pSrc;
			break;
		case (FLD_WORD + 1) * FLD_TYPE + FLD_NMBR:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			*(PUCHR)(pDst+sizeof(sint)) = '\0';
			break;
		case (FLD_WORD + 1) * FLD_TYPE + FLD_WORD:
			*(PSWRD)pDst = *(PSWRD)pSrc;
			break;
		}
       }
}

